﻿/*
 * Created by SharpDevelop.
 * User: PAUL
 * Date: 2/16/2020
 * Time: 2:08 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace StudentInfo
{
	partial class EDIT
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
		private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
		private System.Windows.Forms.Panel panel5;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label3;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.panel1 = new System.Windows.Forms.Panel();
			this.button1 = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.panel3 = new System.Windows.Forms.Panel();
			this.panel4 = new System.Windows.Forms.Panel();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.button8 = new System.Windows.Forms.Button();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.panel5 = new System.Windows.Forms.Panel();
			this.button7 = new System.Windows.Forms.Button();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.button9 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			this.panel5.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Teal;
			this.panel1.Controls.Add(this.button1);
			this.panel1.Controls.Add(this.panel2);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(1, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(957, 147);
			this.panel1.TabIndex = 4;
			// 
			// button1
			// 
			this.button1.BackColor = System.Drawing.Color.Teal;
			this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button1.ForeColor = System.Drawing.Color.White;
			this.button1.Location = new System.Drawing.Point(860, 110);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(97, 37);
			this.button1.TabIndex = 2;
			this.button1.Text = "Log Out";
			this.button1.UseVisualStyleBackColor = false;
			this.button1.Click += new System.EventHandler(this.Button1Click);
			// 
			// panel2
			// 
			this.panel2.Location = new System.Drawing.Point(3, 146);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(187, 68);
			this.panel2.TabIndex = 2;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.White;
			this.label2.Location = new System.Drawing.Point(138, 61);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(672, 53);
			this.label2.TabIndex = 1;
			this.label2.Text = "for Office of  Student Affair Services";
			this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.Color.Teal;
			this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.White;
			this.label1.Location = new System.Drawing.Point(138, 17);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(672, 53);
			this.label1.TabIndex = 0;
			this.label1.Text = "Management Information System";
			this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// panel3
			// 
			this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.panel3.Controls.Add(this.panel4);
			this.panel3.Location = new System.Drawing.Point(2, 146);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(198, 421);
			this.panel3.TabIndex = 5;
			// 
			// panel4
			// 
			this.panel4.BackColor = System.Drawing.Color.Teal;
			this.panel4.Controls.Add(this.button6);
			this.panel4.Controls.Add(this.button5);
			this.panel4.Controls.Add(this.button4);
			this.panel4.Controls.Add(this.button3);
			this.panel4.Controls.Add(this.button2);
			this.panel4.Location = new System.Drawing.Point(9, 11);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(178, 397);
			this.panel4.TabIndex = 2;
			// 
			// button6
			// 
			this.button6.BackColor = System.Drawing.Color.Teal;
			this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button6.ForeColor = System.Drawing.Color.White;
			this.button6.Location = new System.Drawing.Point(27, 302);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(128, 47);
			this.button6.TabIndex = 0;
			this.button6.Text = "EDIT INFO";
			this.button6.UseVisualStyleBackColor = false;
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.ForeColor = System.Drawing.Color.White;
			this.button5.Location = new System.Drawing.Point(27, 236);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(128, 47);
			this.button5.TabIndex = 0;
			this.button5.Text = "VIEW INFO";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.Button5Click);
			// 
			// button4
			// 
			this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.ForeColor = System.Drawing.Color.White;
			this.button4.Location = new System.Drawing.Point(27, 169);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(128, 47);
			this.button4.TabIndex = 0;
			this.button4.Text = "ADD STUDENT";
			this.button4.UseVisualStyleBackColor = false;
			this.button4.Click += new System.EventHandler(this.Button4Click);
			// 
			// button3
			// 
			this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button3.ForeColor = System.Drawing.Color.White;
			this.button3.Location = new System.Drawing.Point(27, 101);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(128, 47);
			this.button3.TabIndex = 0;
			this.button3.Text = "ABOUT";
			this.button3.UseVisualStyleBackColor = false;
			this.button3.Click += new System.EventHandler(this.Button3Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.ForeColor = System.Drawing.Color.White;
			this.button2.Location = new System.Drawing.Point(27, 34);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(128, 47);
			this.button2.TabIndex = 0;
			this.button2.Text = "HOME";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.Button2Click);
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(571, 9);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(154, 20);
			this.textBox9.TabIndex = 19;
			// 
			// button8
			// 
			this.button8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button8.ForeColor = System.Drawing.Color.White;
			this.button8.Location = new System.Drawing.Point(473, 5);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(95, 29);
			this.button8.TabIndex = 18;
			this.button8.Text = "Search";
			this.button8.UseVisualStyleBackColor = false;
			// 
			// dataGridView1
			// 
			this.dataGridView1.BackgroundColor = System.Drawing.Color.Teal;
			this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
			this.Column1,
			this.Column6,
			this.Column7,
			this.Column8,
			this.Column2,
			this.Column3,
			this.Column4,
			this.Column5});
			this.dataGridView1.Location = new System.Drawing.Point(9, 37);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(737, 368);
			this.dataGridView1.TabIndex = 0;
			// 
			// Column1
			// 
			this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column1.HeaderText = "Lastname";
			this.Column1.Name = "Column1";
			// 
			// Column6
			// 
			this.Column6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column6.HeaderText = "Firstname";
			this.Column6.Name = "Column6";
			// 
			// Column7
			// 
			this.Column7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column7.HeaderText = "MI";
			this.Column7.Name = "Column7";
			// 
			// Column8
			// 
			this.Column8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column8.HeaderText = "Extension";
			this.Column8.Name = "Column8";
			// 
			// Column2
			// 
			this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column2.HeaderText = "Gender";
			this.Column2.Name = "Column2";
			// 
			// Column3
			// 
			this.Column3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column3.HeaderText = "Address";
			this.Column3.Name = "Column3";
			// 
			// Column4
			// 
			this.Column4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column4.HeaderText = "Course";
			this.Column4.Name = "Column4";
			// 
			// Column5
			// 
			this.Column5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.Column5.HeaderText = "Year level";
			this.Column5.Name = "Column5";
			// 
			// panel5
			// 
			this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.panel5.Controls.Add(this.button9);
			this.panel5.Controls.Add(this.textBox9);
			this.panel5.Controls.Add(this.button8);
			this.panel5.Controls.Add(this.dataGridView1);
			this.panel5.Controls.Add(this.button7);
			this.panel5.Controls.Add(this.textBox8);
			this.panel5.Controls.Add(this.label10);
			this.panel5.Controls.Add(this.textBox7);
			this.panel5.Controls.Add(this.label9);
			this.panel5.Controls.Add(this.textBox6);
			this.panel5.Controls.Add(this.label8);
			this.panel5.Controls.Add(this.textBox5);
			this.panel5.Controls.Add(this.label7);
			this.panel5.Controls.Add(this.textBox4);
			this.panel5.Controls.Add(this.label6);
			this.panel5.Controls.Add(this.textBox3);
			this.panel5.Controls.Add(this.label5);
			this.panel5.Controls.Add(this.textBox2);
			this.panel5.Controls.Add(this.label4);
			this.panel5.Controls.Add(this.textBox1);
			this.panel5.Controls.Add(this.label3);
			this.panel5.Location = new System.Drawing.Point(200, 147);
			this.panel5.Name = "panel5";
			this.panel5.Size = new System.Drawing.Size(758, 418);
			this.panel5.TabIndex = 7;
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(48, 286);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(126, 47);
			this.button7.TabIndex = 17;
			this.button7.Text = "INSERT";
			this.button7.UseVisualStyleBackColor = true;
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(75, 245);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(63, 20);
			this.textBox8.TabIndex = 16;
			// 
			// label10
			// 
			this.label10.ForeColor = System.Drawing.Color.White;
			this.label10.Location = new System.Drawing.Point(9, 248);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(100, 33);
			this.label10.TabIndex = 15;
			this.label10.Text = "Year level";
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(75, 218);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(63, 20);
			this.textBox7.TabIndex = 14;
			// 
			// label9
			// 
			this.label9.ForeColor = System.Drawing.Color.White;
			this.label9.Location = new System.Drawing.Point(9, 221);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(100, 33);
			this.label9.TabIndex = 13;
			this.label9.Text = "Course";
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(66, 191);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(154, 20);
			this.textBox6.TabIndex = 12;
			// 
			// label8
			// 
			this.label8.ForeColor = System.Drawing.Color.White;
			this.label8.Location = new System.Drawing.Point(9, 194);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(100, 33);
			this.label8.TabIndex = 11;
			this.label8.Text = "Address";
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(75, 165);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(52, 20);
			this.textBox5.TabIndex = 10;
			// 
			// label7
			// 
			this.label7.ForeColor = System.Drawing.Color.White;
			this.label7.Location = new System.Drawing.Point(9, 168);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(100, 33);
			this.label7.TabIndex = 9;
			this.label7.Text = "Gender";
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(75, 136);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(52, 20);
			this.textBox4.TabIndex = 8;
			// 
			// label6
			// 
			this.label6.ForeColor = System.Drawing.Color.White;
			this.label6.Location = new System.Drawing.Point(9, 139);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(100, 33);
			this.label6.TabIndex = 7;
			this.label6.Text = "Extension";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(75, 110);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(52, 20);
			this.textBox3.TabIndex = 6;
			// 
			// label5
			// 
			this.label5.ForeColor = System.Drawing.Color.White;
			this.label5.Location = new System.Drawing.Point(9, 113);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(100, 33);
			this.label5.TabIndex = 5;
			this.label5.Text = "Middle Initial";
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(66, 83);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(154, 20);
			this.textBox2.TabIndex = 4;
			// 
			// label4
			// 
			this.label4.ForeColor = System.Drawing.Color.White;
			this.label4.Location = new System.Drawing.Point(9, 86);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(100, 33);
			this.label4.TabIndex = 3;
			this.label4.Text = "Firstname";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(66, 57);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(154, 20);
			this.textBox1.TabIndex = 2;
			// 
			// label3
			// 
			this.label3.ForeColor = System.Drawing.Color.White;
			this.label3.Location = new System.Drawing.Point(9, 60);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(100, 33);
			this.label3.TabIndex = 1;
			this.label3.Text = "Lastname";
			// 
			// button9
			// 
			this.button9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
			this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button9.ForeColor = System.Drawing.Color.White;
			this.button9.Location = new System.Drawing.Point(9, 4);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(95, 29);
			this.button9.TabIndex = 20;
			this.button9.Text = "Update";
			this.button9.UseVisualStyleBackColor = false;
			// 
			// EDIT
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(982, 608);
			this.Controls.Add(this.panel5);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.panel3);
			this.Name = "EDIT";
			this.Text = "EDIT";
			this.panel1.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			this.panel5.ResumeLayout(false);
			this.panel5.PerformLayout();
			this.ResumeLayout(false);

		}
	}
}
